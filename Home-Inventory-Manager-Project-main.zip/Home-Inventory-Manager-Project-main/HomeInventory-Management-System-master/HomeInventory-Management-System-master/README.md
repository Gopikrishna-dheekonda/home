# HomeInventory-Management-System

This home inventory managemnet is developed on java GUI 
this projects hepls us to manage the appliances at home

With the help of this project we can see an item's location i.e., where it is stored
